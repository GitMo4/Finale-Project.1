package com.example.H2Example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2ExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
